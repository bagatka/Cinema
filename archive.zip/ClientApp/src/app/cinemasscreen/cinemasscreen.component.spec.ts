import { ComponentFixture, TestBed } from '@angular/core/testing';

import { CinemasscreenComponent } from './cinemasscreen.component';

describe('CinemasscreenComponent', () => {
  let component: CinemasscreenComponent;
  let fixture: ComponentFixture<CinemasscreenComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ CinemasscreenComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(CinemasscreenComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
