import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-cinemasscreen',
  templateUrl: './cinemasscreen.component.html',
  styleUrls: ['./cinemasscreen.component.css']
})
export class CinemasscreenComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
