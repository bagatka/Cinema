import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-carousel-list',
  templateUrl: './carousel-list.component.html',
  styleUrls: ['./carousel-list.component.css']
})
export class CarouselListComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
