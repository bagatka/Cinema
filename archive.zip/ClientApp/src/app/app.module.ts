import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';

import { NgxGlideModule } from 'ngx-glide';

import { AppComponent } from './app.component';
import { NavbarComponent } from './navbar/navbar.component';
import { AppRoutingModule } from './app-routing.module';
import { HomescreenComponent } from './homescreen/homescreen.component';
import { CinemasscreenComponent } from './cinemasscreen/cinemasscreen.component';
import { CarouselListComponent } from './carousel-list/carousel-list.component';
import { NgbModule } from '@ng-bootstrap/ng-bootstrap';

@NgModule({
  declarations: [
    AppComponent,
    NavbarComponent,
    HomescreenComponent,
    CinemasscreenComponent,
    CarouselListComponent
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    NgxGlideModule,
    NgbModule.forRoot()
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
